﻿MINDLE MEDIA AI R3 사무실 PC 최종 인수

1. 이 ZIP을 압축 해제합니다.
2. START_R3_OWNER_PC_ACCEPTANCE.cmd를 두 번 클릭합니다.
3. 화면 안내에 따라 Save, Export, Windows 플레이어 재생/탐색/청취, Reopen을 확인합니다.
4. 바탕 화면에 생성된 MINDLE_MEDIA_AI_R3_ACCEPTANCE_*.zip을 회수합니다.

정확한 R3 설치가 필요합니다. 다른 프로세스를 강제 종료하거나 lock 파일을 삭제하지 마세요.
