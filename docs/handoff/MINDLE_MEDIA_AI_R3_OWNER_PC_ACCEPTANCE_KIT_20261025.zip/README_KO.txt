﻿MINDLE MEDIA AI R3 AI 실작동 사무실 PC 인수

1. 이 ZIP을 압축 해제합니다.
2. START_R3_OWNER_PC_ACCEPTANCE.cmd를 두 번 클릭합니다.
3. 실행기는 새 4초 입력을 만들고 Qwen 실제 계획, Supertonic 한국어 신경망 음성, FFmpeg MP4를 반드시 새로 생성합니다.
4. 이어서 화면 안내에 따라 Save, Export, Windows 플레이어 재생/탐색/청취, Reopen을 확인합니다.
5. 바탕 화면의 MINDLE_MEDIA_AI_R3_ACCEPTANCE_*.zip을 회수합니다.

창만 열리고 실제 AI 작업이 실패하면 PASS가 되지 않습니다. 다른 프로세스를 강제 종료하거나 lock 파일을 삭제하지 마세요.
