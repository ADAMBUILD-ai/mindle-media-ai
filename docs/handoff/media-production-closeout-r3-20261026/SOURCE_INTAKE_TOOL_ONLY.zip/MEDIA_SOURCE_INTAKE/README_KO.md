# MEDIA 접수 도구 — 제품 후보 아님

1. 이 ZIP을 새 폴더에 풉니다. Python 3.11 이상과 기존 승인된 FFprobe가 PATH에 있어야 합니다. 모델·EXE·다운로드·설치 기능은 없습니다.
2. OPERATOR_INPUT.json의 null을 실제 파일 경로·장면 설명·사용권·원고·음량·장문 정책으로 바꿉니다. 실제 파일 정보는 자동 측정됩니다. Windows 경로는 C:/Project/video.mp4처럼 /를 쓰면 JSON 역슬래시 이스케이프 문제를 피할 수 있습니다. 영상 항목은 1~12개까지 복사해 추가할 수 있습니다.
3. 이 폴더에서 실행합니다.

python scripts/prepare_media_production_intake.py --request OPERATOR_INPUT.json --out RETURN_01

RETURN_01은 새 폴더여야 합니다. exit 2면 PREPARATION_RECEIPT.json의 누락만 채운 뒤 RETURN_02 같은 새 폴더로 실행합니다. 기존 프로젝트·원본 파일은 수정하지 않습니다.

반환할 것: RETURN_01의 INPUT_MANIFEST.json, PREPARATION_RECEIPT.json, INTAKE_RESULT.json 및 원본 파일에 접근 가능한 PC/NAS 위치. 소스/엔진 사전검사 전 실제 제작은 시작하지 않습니다. 권리 확인과 Windows 엔진/빌드 승인은 별도이며 이 도구는 승인하지 않습니다.

전체 인계 절차: https://github.com/ADAMBUILD-ai/mindle-media-ai/blob/1606e67fae51ae889c88e63b05991ca948ada773/docs/handoff/media-production-closeout-r3-20261026/START_HERE_KO.md
